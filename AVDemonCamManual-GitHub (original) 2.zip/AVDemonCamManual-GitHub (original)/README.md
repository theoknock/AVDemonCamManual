AVDemonCamManual is a modified version of a sample code project distributed by Apple to developers for educational purposes (i.e., AVCamManual). This project also provides video configuration options that are not included in the Camera app for iPhone, but is restricted to only those requisite for the specified type of imaging.

Text requests for support to 408-307-5762.

